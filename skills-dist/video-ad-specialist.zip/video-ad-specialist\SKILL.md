---
name: video-ad-specialist
description: >
  Generates structured short-form video ad scenes for SmartOps IA campaigns
  (Lean Six Sigma and Automacao com IA — never Manutencao TI). ALWAYS use when
  user says "create a video ad", "fazer um video ad", "criar Reels ad", "gerar
  conceito de video", "video ad para Instagram", "video para YouTube Shorts",
  or when video_ad_specialist job runs in the pipeline. Reads research_results.json
  and knowledge files, selects strategy, adapts pacing per platform, generates
  Remotion-compatible scene JSON (all 7 types: hook, problem, product, benefit,
  testimonial, offer, cta). visual field is a DESCRIPTIVE HINT for humans, not
  a functional Remotion parameter. Saves ad_scenes.json then IMMEDIATELY triggers
  remotion-best-practices for rendering. Uses SmartOps IA colors: bg #06060e,
  accent #7c3aed (Lean) or #10b981 (Automacao).
---

# Video Ad Specialist

Generates SmartOps IA video ad scenes for Lean Six Sigma and Automação com IA campaigns, then hands off to Remotion for rendering.

## When to Use This Skill

- Orchestrator pipeline runs `video_ad_specialist` job
- User says "create video ad", "fazer video ad", "criar Reels ad"
- User specifies a platform: Instagram Reels, YouTube Shorts, TikTok
- Do NOT generate for Manutenção TI content

## Step 1: Read Context Files

In order:
1. `knowledge/brand_identity.md` — colors, tone, target audience
2. `knowledge/product_campaign.md` — services, metrics, testimonials, campaign concepts
3. `knowledge/platform_guidelines.md` — platform pacing, format specs
4. `outputs/<task_name>_<date>/research_results.json` — extract:
   - `marketing_angles` → ad strategy
   - `ad_hooks` → opening scene text
   - `video_ideas` → visual concepts
   - `content_topics` → scene narrative

If research JSON not available, infer from knowledge files.

## Step 2: Select Ad Strategy

| Strategy | When to Use | SmartOps IA Context |
|---|---|---|
| `problem_solution` | Pain point → relief | "Equipe apagando incêndio" → Lean method |
| `product_showcase` | Highlight capabilities | Automation bot features, 24h WhatsApp |
| `testimonial` | Social proof | Fernanda's 4-week result, Rodrigo's bot |
| `limited_offer` | Urgency | "Diagnóstico gratuito — só esta semana" |
| `lifestyle` | Aspiration | Running business with confidence and method |
| `meme_style` | High relatability | "Manual de como perder dinheiro com processo ruim" |

Default to `problem_solution` if no campaign goal specified.

## Step 3: Adapt to Platform

**Instagram Reels (1080×1920 vertical)**
```
Hook → Problem → Solution → CTA
Hook: ~3s | Problem: ~4s | Solution: ~5s | CTA: ~3s
Total: 12–15 seconds
```

**YouTube Shorts (1080×1920 vertical)**
```
Hook → Context → DMAIC/Automation reveal → Proof → CTA
Total: 30–45 seconds (YouTube Shorts can be longer)
```

**TikTok (1080×1920 vertical)**
```
Hook → Hook payoff → Quick proof → CTA
Total: 10–15 seconds — fastest pacing
```

## Step 4: Generate Scene JSON

**IMPORTANT:** The `visual` field is a **descriptive hint** for the human designer/editor. It is NOT used by Remotion's `AdVideo.tsx` — the Remotion code uses `type`, `text`, `duration`, `subtext`, `quote`, and `price` only.

### Scene JSON format (for `ad_scenes.json`):

```json
{
  "composition": "AdVideo",
  "props": {
    "style": "problem_solution",
    "duration": 15,
    "platform": "instagram_reels",
    "service": "lean_six_sigma",
    "scenes": [
      {
        "type": "hook",
        "text": "Equipe apagando incêndio todo dia?",
        "visual": "[HINT: chaotic WhatsApp messages animation, red icons]",
        "animation": "scale_in",
        "duration": 3
      },
      {
        "type": "problem",
        "text": "Não é falta de esforço. É processo quebrado.",
        "visual": "[HINT: clock spinning, descending energy arrow]",
        "animation": "fade_slide",
        "duration": 4
      },
      {
        "type": "product",
        "text": "DMAIC identifica a causa raiz. 4 semanas.",
        "visual": "[HINT: DMAIC flow diagram, D→M→A→I→C animated boxes]",
        "animation": "energy_radiate",
        "duration": 5
      },
      {
        "type": "cta",
        "text": "Diagnóstico Grátis.",
        "subtext": "30 minutos · Sem compromisso",
        "visual": "[HINT: rising arrow, WhatsApp green glow]",
        "animation": "arrow_sweep",
        "duration": 3
      }
    ]
  }
}
```

### All Valid Scene Types

| Type | Description | SmartOps IA Use |
|---|---|---|
| `hook` | Opening attention grab | "Equipe apagando incêndio?" / "Seu WhatsApp responde às 3h?" |
| `problem` | Pain point statement | Retrabalho, processo sem padrão, perda de cliente |
| `product` | Method/service reveal | DMAIC steps, automation bot features |
| `benefit` | Sequential bullet list | Quick wins 2–4 semanas, −30% custo, 24h atendimento |
| `testimonial` | Social proof quote | Fernanda O. / Rodrigo M. real quotes |
| `offer` | Urgency / pricing | "Diagnóstico gratuito · 30 minutos" |
| `cta` | Call to action | Always last — WhatsApp link |

**Testimonial scene:**
```json
{
  "type": "testimonial",
  "text": "\"Em 4 semanas o processo ficou padronizado. Resultado real, não promessa.\"",
  "quote": "— Fernanda O., Diretora · Clínica Odontológica",
  "duration": 4
}
```

**Offer scene:**
```json
{
  "type": "offer",
  "text": "Diagnóstico gratuito em 30 minutos",
  "price": "Grátis",
  "subtext": "Sem compromisso · Resposta em até 30 min",
  "duration": 3
}
```

## Step 5: Multi-Platform Handling

When `platform_targets` includes both instagram and youtube:
1. Generate **one scene JSON** using the instagram_reels pacing (shorter)
2. Note in the JSON that a YouTube Shorts version requires a longer cut (30–45s)
3. Worker renders the instagram version by default
4. For YouTube, duplicate and extend duration on `product` and `benefit` scenes

## Step 6: Save and Trigger Remotion

Save scene JSON:
```
outputs/<task_name>_<date>/video/ad_scenes.json
```

Then immediately invoke `remotion-best-practices` skill. Do not wait for user confirmation — rendering is automatic.

## Examples

### Example 1: Lean Six Sigma Campaign

**Context:** `campaign_goal: "conversion"`, `platform_targets: ["instagram"]`

**Strategy:** `problem_solution` — hook with pain, reveal with DMAIC, proof with case

**Scenes:**
1. Hook (3s): "Equipe apagando incêndio todo dia?"
2. Problem (4s): "Sem padrão, cada dia é diferente. Processo quebrado."
3. Product (5s): "DMAIC: Define, Meça, Analise, Melhore, Controle. 4 semanas."
4. CTA (3s): "Diagnóstico Grátis." / subtext: "30 minutos · smartops-ia.com.br"

### Example 2: Automação com IA Campaign

**Context:** `campaign_goal: "awareness"`, `platform_targets: ["instagram", "youtube"]`

**Strategy:** `product_showcase` — show the bot in action

**Scenes:**
1. Hook (3s): "Seu WhatsApp responde quando você está dormindo?"
2. Product (5s): "Bot com IA: responde, qualifica e agenda 24h por dia."
3. Testimonial (4s): "Rodrigo M.: equipe só pega casos que precisam de atenção humana."
4. CTA (3s): "Diagnóstico Grátis." / subtext: "1–2 semanas para automação simples"

## Quality Checklist

- [ ] Service identified: lean_six_sigma OR automacao_ia only
- [ ] Knowledge files and research JSON read
- [ ] Strategy selected and noted in JSON
- [ ] Platform pacing applied correctly
- [ ] `visual` field clearly marked as `[HINT: ...]` — not a functional parameter
- [ ] All required scene fields present (type, text, duration)
- [ ] `ad_scenes.json` saved to correct output path
- [ ] `remotion-best-practices` skill triggered immediately after
- [ ] No Manutenção TI content in any scene

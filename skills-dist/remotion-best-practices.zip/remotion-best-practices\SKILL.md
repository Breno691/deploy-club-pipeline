---
name: remotion-best-practices
description: >
  Renders SmartOps IA video ad compositions using Remotion from scene JSON.
  ALWAYS triggered automatically right after video-ad-specialist generates
  ad_scenes.json — do not wait for user confirmation. Also use when user says
  "render video", "renderizar video", "render with Remotion", "gerar o mp4",
  or references an ad_scenes.json file. Handles all 7 scene types with inline
  SVG animations. Uses SmartOps IA palette: bg #06060e, fg #e8e8f0, muted
  #8b8baa, accent #7c3aed (Lean) and #10b981 (Automacao). System fonts only
  (no Google Fonts). Outputs ad.mp4 to outputs/task_name_date/video/.
---

# Remotion Best Practices

Renders SmartOps IA video ad compositions from scene JSON. Automatically triggered by `video-ad-specialist`.

## When to Use This Skill

- `video-ad-specialist` just generated `ad_scenes.json` (automatic)
- User says "render video", "renderizar video", "gerar mp4", "render with Remotion"
- User references an `ad_scenes.json` file

## Step 1: Parse Scene JSON

Read:
```
outputs/<task_name>_<date>/video/ad_scenes.json
```

Extract: `props.style`, `props.duration`, `props.platform`, `props.service`, `props.scenes`

**Note:** The `visual` field in each scene is a descriptive hint for humans — ignore it during rendering. Use only `type`, `text`, `subtext`, `quote`, `price`, `duration`.

## Step 2: Set Composition Parameters

Configure based on `props.platform`:

| Platform | Width | Height | FPS | Total Frames |
|---|---|---|---|---|
| instagram_reels | 1080 | 1920 | 30 | `props.duration × 30` |
| youtube_shorts | 1080 | 1920 | 30 | `props.duration × 30` |
| tiktok | 1080 | 1920 | 30 | `props.duration × 30` |
| instagram_square | 1080 | 1080 | 30 | `props.duration × 30` |

Default to `instagram_reels` if platform is missing.

## Step 3: SmartOps IA Brand Tokens

**Full color palette (never use arbitrary values):**

```ts
const S = {
  // Backgrounds
  bg: '#06060e',          // Primary background
  bg2: '#0d0d1c',         // Secondary background
  bg3: '#13132a',         // Tertiary background

  // Text
  fg: '#e8e8f0',          // Primary text
  muted: '#8b8baa',       // Secondary text

  // Lean Six Sigma accent (purple)
  accent: '#7c3aed',      // Primary purple
  accentL: '#a78bfa',     // Light purple
  accentC: '#c4b5fd',     // Lighter purple
  accentBorder: 'rgba(167,139,250,0.18)',
  accentGlow: 'rgba(124,58,237,0.18)',

  // Automação com IA accent (emerald)
  green: '#10b981',       // Emerald primary
  greenL: '#6ee7b7',      // Emerald light

  // UI
  whatsapp: '#25d366',    // WhatsApp CTA green
  star: '#fbbf24',        // Stars / highlights
  error: '#f87171',       // Error / problem markers
  border: 'rgba(255,255,255,0.07)',

  // System font (matches site exactly)
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
};
```

**Determine service accent from scene JSON:**
```ts
const isLean = props.service === 'lean_six_sigma' || props.style?.includes('lean');
const accent = isLean ? S.accent : S.green;
const accentL = isLean ? S.accentL : S.greenL;
```

## Step 4: Scene Components with SVG Animations

All animations use `useCurrentFrame()` + `interpolate()`. No CSS keyframes.

### Animation Utilities

```tsx
const frame = useCurrentFrame();
const { fps } = useVideoConfig();

const fadeIn = (start = 0, end = 20) =>
  interpolate(frame, [start, end], [0, 1], { extrapolateRight: 'clamp' });

const slideUp = (start = 0, end = 20, dist = 40) =>
  interpolate(frame, [start, end], [dist, 0], {
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.quad),
  });

const springScale = (offset = 0) =>
  spring({ frame: frame - offset, fps, config: { damping: 12, stiffness: 80 } });
```

### Hook Scene (dark bg, accent glow, text slide-in)

```tsx
<AbsoluteFill style={{ background: S.bg }}>
  {/* Radial glow */}
  <svg style={{ position: 'absolute', width: '100%', height: '100%' }}>
    <radialGradient id="glow" cx="50%" cy="40%" r="50%">
      <stop offset="0%" stopColor={accent} stopOpacity="0.18"/>
      <stop offset="100%" stopColor={accent} stopOpacity="0"/>
    </radialGradient>
    <rect width="100%" height="100%" fill="url(#glow)" />
  </svg>

  {/* Service pill label */}
  <div style={{ opacity: fadeIn(0, 15), fontSize: 11, fontWeight: 800,
    textTransform: 'uppercase', letterSpacing: '0.14em', color: accentL,
    border: `1px solid ${S.accentBorder}`, background: `${accent}20`,
    padding: '5px 14px', borderRadius: 9999 }}>
    {isLean ? 'Lean Six Sigma' : 'Automação com IA'}
  </div>

  {/* Main headline */}
  <div style={{ opacity: fadeIn(10, 35),
    transform: `translateY(${slideUp(10, 35)}px)`,
    fontFamily: S.font, fontSize: 72, fontWeight: 800,
    letterSpacing: '-0.04em', color: S.fg, lineHeight: 1.1 }}>
    {scene.text}
  </div>

  {/* Accent line */}
  <div style={{
    width: interpolate(frame, [35, 60], [0, 100], { extrapolateRight: 'clamp' }),
    height: 3, background: accentL, marginTop: 24, borderRadius: 2
  }} />
</AbsoluteFill>
```

### Problem Scene (dark bg2, spinning clock, error colors)

```tsx
const clockRotation = interpolate(frame, [0, fps * 3], [0, 720]);
const arrowY = interpolate(frame, [0, fps * 2], [0, 40]);

{/* Problem X marker */}
<div style={{ color: S.error, fontWeight: 800, fontSize: 48 }}>✗</div>

{/* Spinning clock SVG */}
<svg viewBox="0 0 100 100" width={120} height={120}>
  <circle cx="50" cy="50" r="44" stroke={S.error} strokeWidth="3" fill="none"/>
  <line x1="50" y1="50" x2="50" y2="18" stroke={S.fg} strokeWidth="3"
    strokeLinecap="round"
    style={{ transformOrigin: '50px 50px', transform: `rotate(${clockRotation}deg)` }}/>
</svg>

{/* Descending energy arrow */}
<svg viewBox="0 0 50 100" width={50} height={100}
  style={{ transform: `translateY(${arrowY}px)` }}>
  <line x1="25" y1="10" x2="25" y2="80" stroke={S.error} strokeWidth="4" strokeLinecap="round"/>
  <polygon points="10,65 25,90 40,65" fill={S.error}/>
</svg>
```

### Product Scene (DMAIC flow or automation reveal)

```tsx
const scale = springScale(5);
const energyOpacity = interpolate(frame % (fps * 0.8), [0, fps * 0.4, fps * 0.8], [0.2, 0.6, 0.2]);

{/* Service-specific visual */}
{isLean ? (
  // DMAIC flow boxes
  <div style={{ display: 'flex', gap: 8, opacity: scale }}>
    {['D', 'M', 'A', 'I', 'C'].map((step, i) => (
      <div key={step} style={{
        opacity: interpolate(frame, [i * 6, i * 6 + 12], [0, 1], { extrapolateRight: 'clamp' }),
        background: S.bg3, border: `1px solid ${S.accentBorder}`,
        borderRadius: 8, padding: '12px 16px',
        color: accentL, fontWeight: 800, fontSize: 18
      }}>{step}</div>
    ))}
  </div>
) : (
  // Automation bot visual
  <svg viewBox="0 0 120 120" width={160} height={160} style={{ transform: `scale(${scale})` }}>
    <rect x="10" y="10" width="100" height="100" rx="20" fill={S.bg2}
      stroke={S.green} strokeWidth="2"/>
    <circle cx="40" cy="50" r="10" fill={S.greenL} opacity={energyOpacity}/>
    <circle cx="60" cy="50" r="10" fill={S.greenL} opacity={energyOpacity * 0.8}/>
    <circle cx="80" cy="50" r="10" fill={S.greenL} opacity={energyOpacity * 0.6}/>
    <text x="60" y="85" textAnchor="middle" fill={S.muted}
      fontSize="12" fontFamily={S.font}>IA · 24h</text>
  </svg>
)}
```

### Benefit Scene (sequential bullets with checkmarks)

```tsx
{bullets.map((bullet: string, index: number) => {
  const startF = index * 12 + 5;
  return (
    <div key={index} style={{
      opacity: interpolate(frame, [startF, startF + 10], [0, 1], { extrapolateRight: 'clamp' }),
      transform: `translateX(${interpolate(frame, [startF, startF + 12], [-30, 0], { extrapolateRight: 'clamp' })}px)`,
      display: 'flex', alignItems: 'center', gap: 16,
    }}>
      <svg viewBox="0 0 44 44" width={40} height={40}>
        <circle cx="22" cy="22" r="20" fill={S.bg2} stroke={accentL} strokeWidth="1.5"/>
        <polyline points="12,22 19,30 33,14" stroke={accentL}
          strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <span style={{ fontFamily: S.font, fontSize: 36, color: S.fg }}>{bullet}</span>
    </div>
  );
})}
```

### Testimonial Scene (quote card with border)

```tsx
const quoteOpacity = fadeIn(0, 25);
const lineWidth = interpolate(frame, [10, 50], [0, 120], { extrapolateRight: 'clamp' });

<AbsoluteFill style={{ background: S.bg2, display: 'flex', flexDirection: 'column',
  alignItems: 'center', justifyContent: 'center', padding: '80px 64px' }}>

  {/* Decorative quote mark */}
  <div style={{ fontSize: 100, lineHeight: 0.8, color: accentL, opacity: 0.2,
    fontFamily: 'Georgia, serif', alignSelf: 'flex-start' }}>"</div>

  {/* Quote text */}
  <div style={{ opacity: quoteOpacity, fontFamily: S.font, fontSize: 44,
    fontStyle: 'italic', color: S.fg, textAlign: 'center',
    lineHeight: 1.3, maxWidth: 900 }}>{scene.text}</div>

  {/* Accent line */}
  <div style={{ width: lineWidth, height: 2, background: accentL, margin: '32px auto 24px' }}/>

  {/* Attribution */}
  {scene.quote && (
    <div style={{ opacity: fadeIn(25, 45), fontFamily: S.font, fontSize: 16,
      color: S.muted, textAlign: 'center', letterSpacing: 1 }}>{scene.quote}</div>
  )}
</AbsoluteFill>
```

### Offer Scene (price badge with spring)

```tsx
const priceScale = springScale(15);

<div style={{ background: S.whatsapp, color: '#fff',
  fontFamily: S.font, fontSize: 64, fontWeight: 800,
  padding: '16px 48px', borderRadius: 12,
  transform: `scale(${Math.max(0, priceScale)})`,
  boxShadow: `0 4px 24px ${S.whatsapp}40` }}>
  {scene.price}
</div>
```

### CTA Scene (rising arrow + WhatsApp green)

```tsx
const arrowY = interpolate(frame, [0, fps * 2], [200, -80]);
const textScale = springScale(0);

{/* Rising arrow background */}
<svg viewBox="0 0 80 160" width={80} height={160}
  style={{ position: 'absolute', transform: `translateY(${arrowY}px)`, opacity: 0.15 }}>
  <line x1="40" y1="160" x2="40" y2="40" stroke={S.whatsapp} strokeWidth="8" strokeLinecap="round"/>
  <polygon points="20,70 40,20 60,70" fill={S.whatsapp}/>
</svg>

{/* Main CTA */}
<div style={{ fontFamily: S.font, fontSize: 80, fontWeight: 800,
  color: S.fg, transform: `scale(${textScale})` }}>{scene.text}</div>

{/* Subtext */}
{scene.subtext && (
  <div style={{ opacity: fadeIn(20, 40), fontFamily: S.font, fontSize: 24,
    color: S.muted, textAlign: 'center' }}>{scene.subtext}</div>
)}

{/* Brand watermark */}
<div style={{ position: 'absolute', bottom: 64,
  fontFamily: S.font, fontSize: 16, color: S.muted,
  letterSpacing: 3, textTransform: 'uppercase',
  opacity: fadeIn(30, 50) }}>SmartOps IA</div>
```

## Step 5: Scene Transitions

Between scenes, apply a cross-fade by tracking scene entry frame:

```tsx
const FADE_FRAMES = 8;
const fadeInProgress = Math.min(1, sceneFrame / FADE_FRAMES);
// Apply to AbsoluteFill: style={{ opacity: fadeInProgress }}
```

## Step 6: Correct Render Command

```bash
npx remotion render remotion/src/index.ts AdVideo \
  "outputs/<task_name>_<date>/video/ad.mp4" \
  --props '{"style":"problem_solution","duration":15,"platform":"instagram_reels","service":"lean_six_sigma","scenes":[...]}'
```

Or pass the JSON file path:
```bash
npx remotion render remotion/src/index.ts AdVideo \
  "outputs/<task_name>_<date>/video/ad.mp4"
```

## Troubleshooting

### "Cannot find module remotion"
**Solution:** `cd remotion && npm install`

### durationInFrames must be a positive integer
**Cause:** `props.duration` missing or 0
**Solution:** Default to 15 seconds (450 frames at 30fps) if duration is missing

### TypeScript error on scene type
**Cause:** Scene `type` value not in schema enum
**Solution:** Schema accepts: `hook`, `problem`, `product`, `benefit`, `testimonial`, `offer`, `cta` only

### Grain overlay not showing
**Cause:** SVG `feTurbulence` not rendering in all Chromium versions
**Solution:** Grain is optional — skip if it causes issues, the design works without it

## Quality Checklist

- [ ] Scene JSON read from correct output path
- [ ] `visual` field ignored — not passed to React components
- [ ] Composition dimensions match platform (default: 1080×1920)
- [ ] SmartOps IA brand tokens used (no arbitrary hex values)
- [ ] Service accent applied: purple for Lean, emerald for Automação
- [ ] All 7 scene types have handlers
- [ ] Render command includes entry point path: `remotion/src/index.ts`
- [ ] Output saved to `outputs/<task_name>_<date>/video/ad.mp4`
- [ ] No Manutenção TI content in any scene

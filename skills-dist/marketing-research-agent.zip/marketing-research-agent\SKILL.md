---
name: marketing-research-agent
description: >
  Runs structured market intelligence research for SmartOps IA campaigns using
  Tavily AI web search. ALWAYS use when user says "run research", "research the
  market", "get marketing insights", "analyze trends", "pesquisar mercado",
  "buscar insights", "fazer pesquisa de campanha", or when the Orchestrator
  pipeline starts with skip_research false. Executes 5 targeted Tavily searches
  covering Lean Six Sigma market trends, competitor messaging, small business
  audience pain points (process problems, rework, WhatsApp chaos), high-converting
  hooks, and viral content patterns for process improvement and automation content.
  Saves three deliverables to outputs/task_name_date/: research_results.json,
  research_brief.md, and interactive_report.html. Always run FIRST.
  NEVER research or include Manutencao TI content.
---

# Marketing Research Agent

Runs 5 targeted Tavily searches to generate SmartOps IA marketing intelligence consumed by downstream agents.

## When to Use This Skill

- Orchestrator pipeline starts with `skip_research: false`
- User says "run research", "pesquisar mercado", "get marketing insights"
- Always the FIRST agent — never skip unless `skip_research: true` AND source folder exists

## Step 1: Read Context Files

Before any search, read:
1. `knowledge/brand_identity.md` — brand, services (Lean + Automação only), audience, tone
2. `knowledge/product_campaign.md` — selling points, metrics, campaign concepts

Extract:
- Primary services: Lean Six Sigma + Automação com IA (never Manutenção TI)
- Target audience: donos de pequenas empresas, BH and região
- Core pain points: retrabalho, processo sem padrão, WhatsApp caótico

## Step 2: Run 5 Tavily Searches

Execute:
```bash
node scripts/research.js --task "<task_name>" --date "<date>"
```

The script runs these 5 searches:

| # | Category | Example Query |
|---|---|---|
| 1 | Market Trends | "Lean Six Sigma pequenas empresas Brasil 2026 tendências" |
| 2 | Competitor Messaging | "consultoria Lean Six Sigma automação processos pequenas empresas BH concorrentes" |
| 3 | Audience Pain Points | "problemas operacionais pequenas empresas Brasil retrabalho desperdício processo" |
| 4 | Ad Hooks & Angles | "melhores hooks marketing consultoria processos automação pequena empresa" |
| 5 | Viral Topics | "conteúdo viral melhoria contínua automação IA pequenas empresas Instagram 2026" |

Queries are in Portuguese for better Brazilian market results. English variants also valid for broader data.

## Step 3: Evaluate Data Quality

After the script completes, check `research_results.json → data_source`:

- `"tavily"` — real research data used. High confidence in results.
- `"brand_defaults"` — API failed or returned empty. Fallback to SmartOps IA brand defaults.

If `data_source: "brand_defaults"`, note this in the research brief so downstream agents know results are estimated, not real-time.

**Check for existing results:** If `research_results.json` already exists for this task/date and `data_source: "tavily"`, ask the user: "Research results exist from a previous run. Re-run or reuse?" Default: reuse unless user says otherwise.

## Step 4: Synthesize Research Findings

Expected output structure in `research_results.json`:

```json
{
  "task_name": "<task_name>",
  "date": "<date>",
  "data_source": "tavily",
  "product": "SmartOps IA",
  "services": ["Lean Six Sigma", "Automação com IA"],
  "target_audience": "Donos de pequenas empresas em BH e região",
  "campaign_focus": "Lean Six Sigma + Automação com IA (sem Manutenção TI)",
  "content_topics": [
    "Como eliminar retrabalho com Lean Six Sigma em pequenas empresas",
    "Lean primeiro, automação depois — a sequência que funciona",
    "DMAIC na prática: causa raiz em 4 semanas",
    "Atendimento WhatsApp com IA: quando vale e quando não vale"
  ],
  "marketing_angles": [
    "O processo está quebrado — não a equipe",
    "Automatizar processo ruim só faz errar mais rápido",
    "Em 4 semanas, de equipe apagando incêndio para processo padronizado",
    "3h da manhã — seu bot responde, sua equipe descansa"
  ],
  "keywords": [
    "Lean Six Sigma", "DMAIC", "melhoria de processos", "automação com IA",
    "WhatsApp Business IA", "pequenas empresas BH", "redução de desperdício",
    "processo padronizado", "Black Belt", "consultoria processos"
  ],
  "ad_hooks": [
    "Equipe apagando incêndio todo dia não é falta de esforço. É processo quebrado.",
    "Automatizou sem mapear o processo? Acabou de automatizar o erro.",
    "Em 4 semanas o retrabalho foi eliminado. 3 meses de tentativa não resolveram.",
    "Seu WhatsApp responde às 3h da manhã?",
    "Lean primeiro. Automação depois. Essa sequência muda o jogo."
  ],
  "video_ideas": [
    "DMAIC em 60 segundos — as 5 fases com exemplo real",
    "Os 8 desperdícios do Lean em empresas de serviço — qual está custando mais?",
    "Como montar um bot WhatsApp com IA sem saber programar",
    "Antes e depois: processo de atendimento com e sem padronização"
  ],
  "competitor_gaps": [
    "Concorrentes focam em grandes empresas — SmartOps IA especializada em pequenas",
    "Outros vendem curso — SmartOps IA entrega projeto com resultado fechado",
    "Poucos combinam Lean + Automação IA no mesmo escopo",
    "Proposta com custo, prazo e resultado definidos antes de começar — raro no mercado"
  ],
  "trending_windows": {
    "instagram": "Terça–Quinta, 7h–9h BRT ou 12h–13h BRT",
    "youtube": "Quarta–Sábado, 14h–17h BRT",
    "threads": "Dias úteis, 8h–10h BRT"
  },
  "raw_summary": {
    "trends": "",
    "competitors": "",
    "audience": "",
    "hooks": "",
    "viral": ""
  }
}
```

Save to: `outputs/<task_name>_<date>/research_results.json`

## Step 5: Generate Research Brief (Markdown)

Write `outputs/<task_name>_<date>/research_brief.md`:

```markdown
# Research Brief: SmartOps IA — <task_name> · <date>

> Data source: [tavily / brand_defaults]

## Executive Summary
[2–3 sentences: main insight + recommended campaign angle]

## Market Trends
[Lean Six Sigma and automation market in Brazil — what's growing]

## Competitor Analysis
[Positioning gaps, pricing, messaging from competitors]

## Audience Pain Points
[Top operational problems in small businesses right now]

## Top Ad Hooks
[5 hooks ranked by likely conversion potential]

## Viral Content Opportunity
[What format/topic is getting engagement in this niche]

## Recommended Campaign Angle
**Selected:** [one angle that works across all platforms]
**Reason:** [why this one, not the others]

## Campaign Flow
\`\`\`mermaid
graph LR
  A[Hook: Dor operacional] --> B[Método: Lean/Automação]
  B --> C[Prova: caso real + número]
  C --> D[CTA: Diagnóstico gratuito]
\`\`\`

## Scheduling Recommendations
| Platform | Best Times |
|---|---|
| Instagram | [times] |
| YouTube | [times] |
| Threads | [times] |
```

## Step 6: Generate Interactive HTML Report

Write `outputs/<task_name>_<date>/interactive_report.html` — branded dashboard with:

- SmartOps IA dark theme: `background: #06060e`, `color: #e8e8f0`
- Purple accent: `#7c3aed` / `#a78bfa` for Lean, Green `#10b981` for Automação
- Summary cards: hooks count, keywords, competitor gaps, recommended angle
- Chart.js: keyword frequency or competitor positioning bar chart
- System font stack (no Google Fonts needed)

## Step 7: Log Completion

Write to `outputs/<task_name>_<date>/logs/research_agent.log`:
```
[timestamp] Research Agent started
[timestamp] Context files read: brand_identity.md, product_campaign.md
[timestamp] Tavily search 1/5: trends — [result count] results
[timestamp] Tavily search 2/5: competitors — [result count] results
[timestamp] Tavily search 3/5: audience — [result count] results
[timestamp] Tavily search 4/5: hooks — [result count] results
[timestamp] Tavily search 5/5: viral — [result count] results
[timestamp] data_source: tavily/brand_defaults
[timestamp] research_results.json saved
[timestamp] research_brief.md saved
[timestamp] interactive_report.html saved
[timestamp] Research Agent complete ✓
```

## Troubleshooting

### All searches return empty / error
**Cause:** `TAVILY_API_KEY` missing or expired
**Solution:** Check `.env`. Fallback to brand_defaults is automatic but note it in brief.

### Output path not found
**Cause:** Task name has spaces or special characters
**Solution:** Use only `snake_case` with letters, numbers, underscore

### Research includes Manutenção TI content
**This should never happen.** The script queries are scoped to Lean + Automação.
If it appears in raw results, exclude it from synthesis — it's not part of this pipeline.

## Quality Checklist

- [ ] Knowledge files read before generating queries
- [ ] 5 Tavily searches executed
- [ ] `data_source` field set correctly (`tavily` or `brand_defaults`)
- [ ] `research_results.json` has all required fields
- [ ] No Manutenção TI content in any field
- [ ] `research_brief.md` includes Mermaid campaign flow diagram
- [ ] `interactive_report.html` uses SmartOps IA dark theme
- [ ] Log file written with per-search result counts

---
name: copywriter-agent
description: >
  Generates platform-native marketing copy for SmartOps IA campaigns covering
  Lean Six Sigma and Automacao com IA (never Manutencao TI). ALWAYS use when
  user says "write copy", "escrever copy", "gerar captions", "write Instagram
  caption", "criar legenda Instagram", "write YouTube title", "criar titulo
  YouTube", "escrever post", or when copywriter_agent job runs in the pipeline.
  Calls scripts/generate_copy.js which uses the Claude API with all knowledge
  files and research_results.json as context. Enforces single campaign angle,
  specific numbers in every claim (−30%, 4 semanas, 30 minutos, 24h), and
  platform tone (Threads=technical/direct, Instagram=proof+method, YouTube=
  educational). Outputs 3 files to outputs/task_name_date/copy/.
---

# Copywriter Agent

Generates SmartOps IA platform-native copy for Lean Six Sigma and Automação com IA campaigns.

## When to Use This Skill

- Research Agent completed and `research_results.json` exists
- Orchestrator pipeline reaches copywriting step
- User asks for "copy", "captions", "YouTube title", "escrever post"
- Runs after Research, never before

## CRITICAL: This Agent Uses a Script

**Primary flow:** The worker calls `scripts/generate_copy.js` which uses the Claude API.

```bash
node scripts/generate_copy.js --task <task_name> --date <task_date>
```

The steps below document what the script does internally and serve as a fallback if the script fails.

## CRITICAL: Mandatory Numbers Rule

Every single piece of copy must contain at least one specific number from this list:

| Metric | Value |
|---|---|
| Cost reduction | −30% |
| First response | 24h |
| Lean quick wins | 2–4 semanas |
| Simple automation | 1–2 semanas |
| Diagnosis duration | 30 minutos |
| DMAIC project | 6–12 semanas |
| Automation uptime | 3h da manhã |
| Example result | 4 semanas (clínica) |

**WRONG:** "Lean Six Sigma melhora sua operação"
**CORRECT:** "Em 4 semanas, a clínica eliminou o retrabalho que 3 meses não resolveram"

## Step 1: Read Context Files

In order:
1. `knowledge/brand_identity.md` → tone per platform, CTA language, what NOT to write
2. `knowledge/product_campaign.md` → services (Lean + Automação only), testimonials, metrics
3. `knowledge/platform_guidelines.md` → per-platform format constraints
4. `outputs/<task_name>_<date>/research_results.json` → `marketing_angles`, `ad_hooks`, `keywords`

## Step 2: Select and Document Campaign Angle

From `research_results.json → marketing_angles`, select ONE:

```
Selected angle: "O processo está quebrado — não a equipe"
Proof number: 4 semanas · −30% custo
Hook: "Equipe apagando incêndio todo dia? Não é falta de esforço."
Service: lean_six_sigma
```

Log this at the top of `outputs/<task_name>_<date>/logs/copywriter_agent.log`.
This same angle applies across ALL three platforms.

## Step 3: Write Threads Post

Rules:
- Max 500 characters — verify before saving
- 2–3 short sentences, auto-sufficient
- Most direct and technical tone of all platforms
- 0–1 hashtags, never leads with hashtag
- No mandatory CTA — can end with rhetorical question or insight
- Must contain one specific number

**Format options:**

```
[Technical insight with real number]

[Desmistificação ou observação seca]

[Pergunta retórica ou desafio]
```

**SmartOps IA Threads examples:**
```
Automatizar processo ruim só faz você errar mais rápido.

Lean primeiro. Automação depois. Essa sequência muda o jogo.
```
```
4 semanas. Processo de atendimento padronizado. Time parou de improvisar.

Isso é DMAIC em clínica odontológica. Não teoria — resultado real.
```
```
Equipe apagando incêndio todo dia não é falta de esforço.

É o processo quebrando sempre no mesmo ponto. DMAIC identifica onde. #LeanSixSigma
```

Save to: `outputs/<task_name>_<date>/copy/threads_post.txt`
**Validate:** `len(threads_post) <= 500 characters`

## Step 4: Write Instagram Caption

Rules:
- 2–4 sentences before hashtags
- Structure: Case/Hook → Method (Lean or Automação) → Result (with number) → CTA → Hashtags
- Max 1 emoji, only if it adds context
- 4–6 hashtags after line break
- CTA is mandatory: "Diagnóstico gratuito no link da bio"
- Must contain two specific numbers

**Format:**
```
[Hook: caso real ou dor com impacto]

[Método: o que foi feito, sem jargão excessivo]

[Resultado: número + prazo]

[CTA]

#SmartOpsIA #LeanSixSigma #[niche] #[keyword] #PequenasEmpresas #BH
```

**SmartOps IA Instagram examples:**

For Lean:
```
3 meses tentando resolver retrabalho. 4 semanas com o método Lean o processo ficou padronizado e o time parou de perguntar o que fazer.

DMAIC não é teoria — é diagnóstico, causa raiz, melhoria e controle. Em clínicas, restaurantes, e-commerces. Qualquer processo que se repete pode ser padronizado.

Diagnóstico gratuito de 30 minutos. Link na bio.

#SmartOpsIA #LeanSixSigma #DMAIC #MelhoriaDeProcessos #PequenasEmpresas #BH
```

For Automação:
```
Automatizamos o atendimento no WhatsApp. Hoje o sistema responde clientes às 3h da manhã, qualifica e agenda. A equipe só pega casos que precisam de atenção humana.

Automação simples fica pronta em 1–2 semanas. Mas só funciona bem depois do processo estar mapeado. Lean primeiro, automação depois.

Diagnóstico gratuito no link da bio.

#SmartOpsIA #AutomacaoIA #WhatsAppBusiness #AutomacaoDeProcessos #PequenasEmpresas
```

Save to: `outputs/<task_name>_<date>/copy/instagram_caption.txt`

## Step 5: Write YouTube Metadata

Rules:
- Title: 50–65 characters (validates SEO + avoid truncation)
- Must include keyword: Lean Six Sigma OR Automação com IA OR DMAIC OR WhatsApp IA
- Always ends with `| SmartOps IA`
- Description: 3–4 sentences + link placeholder
- Tags: 10–14 total

**Title formula:**
`[Ação/resultado] + [contexto específico] + [prazo/número] | SmartOps IA`

**Examples:**
```
Como Eliminar Retrabalho com Lean Six Sigma em 4 Semanas | SmartOps IA
DMAIC na Prática: Clínica Padronizada em 30 Dias | SmartOps IA
Automação WhatsApp com IA: Como Funciona na Prática | SmartOps IA
8 Desperdícios do Lean em Pequenas Empresas | SmartOps IA
```

**Description structure:**
```
[O que o vídeo mostra + número real]

[Contexto da metodologia — quem pode usar, quando funciona]

[Caso prático referenciado se houver]

Diagnóstico gratuito de 30 minutos: smartops-ia.com.br
WhatsApp: (31) 97203-9180
```

**Output format:**
```json
{
  "title": "Como Eliminar Retrabalho com Lean Six Sigma em 4 Semanas | SmartOps IA",
  "description": "Neste vídeo mostro como aplicar o DMAIC para identificar a causa raiz do retrabalho em processos de atendimento. Em 4 semanas, uma clínica odontológica eliminou o problema que 3 meses de tentativa não resolveram. O método funciona em qualquer processo que se repete — restaurantes, e-commerces, serviços. Diagnóstico gratuito de 30 minutos: smartops-ia.com.br",
  "tags": [
    "Lean Six Sigma", "DMAIC", "melhoria de processos", "retrabalho",
    "pequenas empresas", "gestão operacional", "SmartOps IA", "Breno Luiz",
    "Black Belt", "BH", "Belo Horizonte", "consultoria processos",
    "padronização", "eliminação de desperdícios"
  ]
}
```

Save to: `outputs/<task_name>_<date>/copy/youtube_metadata.json`
**Validate:** `len(title) <= 65 characters`

## Step 6: Log Completion

Write to `outputs/<task_name>_<date>/logs/copywriter_agent.log`:
```
[timestamp] Copywriter Agent started
[timestamp] Knowledge files read
[timestamp] research_results.json loaded — data_source: [tavily/brand_defaults]
[timestamp] Selected angle: [angle text]
[timestamp] Service: [lean_six_sigma / automacao_ia]
[timestamp] threads_post.txt saved ([X] chars — VALID/INVALID)
[timestamp] instagram_caption.txt saved
[timestamp] youtube_metadata.json saved — title: [title text] ([N] chars)
[timestamp] Copywriter Agent complete ✓
```

## Troubleshooting

### generate_copy.js fails: ANTHROPIC_API_KEY not set
**Solution:** Add key to `.env`. Fallback: write copy manually following steps above.

### Copy sounds generic / no SmartOps IA tone
**Cause:** Script not reading knowledge files, or generic prompt
**Solution:** Read `brand_identity.md` → "Voice & Tone" section. Every claim needs a number.

### YouTube title over 65 characters
**Cause:** Too much context in title
**Solution:** Move context to description. Title = "Como [verb] [result] [context] | SmartOps IA"

### Manutenção TI content appears in copy
**This must never happen.** Do not write copy for SSD, formatação, vírus, computadores.
Re-read `brand_identity.md → Serviços` section and regenerate.

## Quality Checklist

- [ ] Script `generate_copy.js` ran OR manual copy written following these steps
- [ ] Campaign angle selected and documented in log
- [ ] Service: lean_six_sigma OR automacao_ia (never manutencao_ti)
- [ ] Each piece has at least one specific number
- [ ] Threads: ≤500 characters — verified
- [ ] Instagram: hook + case + result + CTA + 4–6 hashtags
- [ ] YouTube title: ≤65 chars + keyword + "| SmartOps IA"
- [ ] YouTube description: smartops-ia.com.br link included
- [ ] YouTube tags: 10–14 relevant terms
- [ ] All three files saved to `outputs/<task_name>_<date>/copy/`
- [ ] Log file written with character counts

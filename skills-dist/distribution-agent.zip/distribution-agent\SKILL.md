---
name: distribution-agent
description: >
  Handles Supabase media hosting, publish-ready metadata assembly, and post
  scheduling advisory for completed SmartOps IA campaigns (Lean Six Sigma and
  Automacao com IA only). ALWAYS use when user says "upload media", "fazer upload
  da midia", "prepare to publish", "distribuir campanha", "generate publish file",
  "gerar arquivo de publicacao", or when distribution_agent job runs in the
  pipeline after all creative agents complete. Runs upload_media.js to upload
  to Supabase, reads copy outputs, generates scheduling recommendations, and
  writes the Publish advisory MD file. CRITICAL GATE: Real API posting to
  Instagram or YouTube ONLY executes when user references the exact Publish MD
  filename (e.g. "Publish smartops_lean_q3 2026-05-28.md"). Never posts
  automatically. Threads requires manual posting.
---

# Distribution Agent

Hosts SmartOps IA campaign media on Supabase, assembles publish-ready metadata, and gates API posting behind explicit confirmation.

## When to Use This Skill

- All creative pipeline jobs are complete (check `pipeline_state.json`)
- User says "upload media", "prepare to publish", "distribuir campanha"
- User references a Publish MD file by exact name → triggers API posting

## CRITICAL: Publishing Gate Rule

**Never post automatically.**

Real Instagram and YouTube API calls execute ONLY when the user's message contains the exact Publish MD filename:

```
Publish <task_name> <date>.md
```

Example: `"Publish smartops_lean_q3 2026-05-28.md"` unlocks posting.

"Publish now", "go ahead", "posta" — these do NOT trigger posting. Only the exact filename.

After the user references the file, confirm which platforms before executing:
```
Ready to post. Confirm platforms:
[ ] Instagram — will post instagram_ad.png with caption
[ ] YouTube — will upload ad.mp4 with title/description/tags
[ ] Threads — manual only, no API available
```

## Step 1: Collect All Campaign Outputs

Scan `outputs/<task_name>_<date>/` for:
```
├── research_results.json        ← scheduling signals
├── ads/instagram_ad.png         ← Instagram image ad
├── video/ad.mp4                 ← YouTube/Reels video
└── copy/
    ├── instagram_caption.txt
    ├── threads_post.txt
    └── youtube_metadata.json
```

Log each file found/missing. Missing files don't block — note in Publish MD.

## Step 2: Upload Media to Supabase

```bash
node scripts/upload_media.js --task <task_name> --date <task_date>
```

**Pre-upload validation:** The Supabase URL must be publicly accessible for Instagram API.
Test before posting: `curl -I <url>` should return HTTP 200.

Storage naming:
```
campaign-uploads/<task_name>/<date>/instagram_ad.png
campaign-uploads/<task_name>/<date>/ad.mp4
```

Save public URLs to `outputs/<task_name>_<date>/media_urls.json`.

**Partial upload handling:** If one file fails, continue with others. Note failed uploads in Publish MD. Do not block the full distribution on a single file failure.

## Step 3: Read Copy and Generate Scheduling

Read:
- `copy/instagram_caption.txt`
- `copy/threads_post.txt`
- `copy/youtube_metadata.json`
- `research_results.json → trending_windows`
- `knowledge/platform_guidelines.md` → scheduling section

**Default SmartOps IA posting windows:**

| Platform | Best Times | Notes |
|---|---|---|
| Instagram | Terça–Quinta, 7h–9h BRT ou 12h–13h BRT | Morning before work or lunch break |
| YouTube | Quarta–Sábado, 14h–17h BRT | Afternoon browsing, longer shelf life |
| Threads | Dias úteis, 8h–10h BRT | Professional audience morning scroll |

If `research_results.json → trending_windows` has data, prioritize it over defaults.

## Step 4: Generate Publish MD File

Save to: `outputs/<task_name>_<date>/Publish <task_name> <date>.md`

```markdown
# Publish Advisory: SmartOps IA — <task_name> · <date>

## Campaign Summary
- Service: [lean_six_sigma / automacao_ia]
- Campaign angle: [from research_results.json]
- Pipeline completed: [timestamp]

---

## Media Assets (Supabase)

| Asset | URL | Status |
|---|---|---|
| Instagram Ad | [URL or "upload failed"] | [✓ / ✗] |
| Video Ad | [URL or "not generated"] | [✓ / ✗] |

---

## Instagram

**Caption:**
```
[full instagram_caption.txt content]
```

**Hashtags:** [extracted from caption]

**Asset:** instagram_ad.png ([Supabase URL])

**Recommended posting:** [day/time from trending_windows]

**Pre-posting checklist:**
- [ ] Supabase URL returns HTTP 200: `curl -I [url]`
- [ ] INSTAGRAM_ACCESS_TOKEN not expired (expires every ~60 days — check .env comments)
- [ ] Account has permission for image posts

**Post via:** Instagram Graph API v21.0 — reference this Publish MD file by name to execute.

---

## YouTube

**Title:** [from youtube_metadata.json — should be ≤65 chars]

**Description:**
[full description from youtube_metadata.json]

**Tags:** [tags from youtube_metadata.json]

**Asset:** ad.mp4 ([Supabase URL or "not available"])

**Recommended posting:** [day/time from trending_windows]

**Pre-posting checklist:**
- [ ] YOUTUBE_REFRESH_TOKEN set in .env
- [ ] OAuth token not expired — test: `node scripts/test_youtube_auth.js`
- [ ] Video format: MP4, H.264, max 256GB

**Note:** YouTube upload requires Remotion to have rendered ad.mp4.
If ad.mp4 was not generated (skip_video: true), this section cannot be published.

**Post via:** YouTube Data API v3 — reference this Publish MD file by name to execute.

---

## Threads

**Post text:**
```
[full threads_post.txt content]
```

**Character count:** [N] / 500

**Recommended posting:** [day/time]

> **Manual posting required.** No public Threads API. Copy the text above and post at smartops-ia.com.br (link in bio or direct post from the app).

---

## How to Publish via API

Reference this file by exact name to trigger posting:

```
Publish <task_name> <date>.md
```

Then confirm which platforms. Instagram and YouTube will execute via API.
Threads is always manual.

---

## Missing or Failed Items

[List any files that could not be uploaded or were not generated]

---

## Campaign Notes

- data_source: [tavily / brand_defaults]
- Scheduling based on: [research signals / platform defaults]
- All content: Lean Six Sigma + Automação com IA only ✓
```

## Step 5: Execute API Posting (Gate-Protected)

Only runs when user references the Publish MD file by exact name.

### Instagram Graph API (v21.0)

```javascript
// POST image to Instagram
const containerRes = await fetch(
  `https://graph.facebook.com/v21.0/${process.env.INSTAGRAM_ACCOUNT_ID}/media`,
  {
    method: 'POST',
    body: new URLSearchParams({
      image_url: mediaUrls.instagram_ad,  // must be public Supabase URL
      caption: instagramCaption,
      access_token: process.env.INSTAGRAM_ACCESS_TOKEN,
    })
  }
);
const { id: containerId } = await containerRes.json();

// Publish the container
await fetch(
  `https://graph.facebook.com/v21.0/${process.env.INSTAGRAM_ACCOUNT_ID}/media_publish`,
  {
    method: 'POST',
    body: new URLSearchParams({
      creation_id: containerId,
      access_token: process.env.INSTAGRAM_ACCESS_TOKEN,
    })
  }
);
```

**Token expiry:** Instagram access tokens expire approximately every 60 days.
Note the expiry date in `.env` as a comment: `# expires: 2026-07-28`

### YouTube Data API v3

```javascript
const { google } = require('googleapis');
const oauth2Client = new google.auth.OAuth2(
  process.env.YOUTUBE_CLIENT_ID,
  process.env.YOUTUBE_CLIENT_SECRET,
  process.env.YOUTUBE_REDIRECT_URI
);
oauth2Client.setCredentials({ refresh_token: process.env.YOUTUBE_REFRESH_TOKEN });
const youtube = google.youtube({ version: 'v3', auth: oauth2Client });

await youtube.videos.insert({
  part: ['snippet', 'status'],
  requestBody: {
    snippet: {
      title: ytMeta.title,
      description: ytMeta.description,
      tags: ytMeta.tags,
      categoryId: '27',  // Education
      defaultLanguage: 'pt',
    },
    status: { privacyStatus: 'public' },
  },
  media: {
    body: fs.createReadStream(path.join(taskDir, 'video', 'ad.mp4')),
  },
});
```

If `YOUTUBE_REFRESH_TOKEN` not set, skip YouTube and note in Publish MD.

### Threads

No public API. Post text is in the Publish MD for manual copy.

## Troubleshooting

### Supabase upload 403
**Cause:** Bucket not public or wrong service key (anon key ≠ service key)
**Solution:** Verify `SUPABASE_SERVICE_KEY` (not anon key) in `.env`. Check bucket RLS policy.

### Instagram: "Media type not supported"
**Cause:** Account doesn't have permission for the media type
**Solution:** For images: basic Instagram API sufficient. For video/Reels: requires Reels permission on the account.

### Instagram token expired
**Cause:** Access token > 60 days old
**Solution:** Refresh via Facebook Developer portal. Update `.env` and expiry comment.

### YouTube OAuth error
**Cause:** `YOUTUBE_REFRESH_TOKEN` expired or missing
**Solution:** Re-run OAuth flow, update `.env`. Meanwhile, mock the upload and log the intent.

### Publish MD not triggering posting
**Cause:** User didn't include exact filename in message
**Solution:** Remind: "Para publicar, mencione o arquivo pelo nome exato: `Publish <task_name> <date>.md`"

## Quality Checklist

- [ ] All creative jobs verified complete in `pipeline_state.json`
- [ ] Supabase upload ran — `media_urls.json` exists
- [ ] Public URLs accessible (HTTP 200)
- [ ] Copy files read from correct paths
- [ ] Scheduling from `research_results.json → trending_windows` or defaults
- [ ] `Publish <task_name> <date>.md` saved to output folder
- [ ] Token expiry status documented in Publish MD
- [ ] API posting only triggered after exact Publish MD filename referenced
- [ ] No Manutenção TI content in any output
